package com.akh;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AkhApiGatewayApplication {

	public static void main(String[] args) {
		SpringApplication.run(AkhApiGatewayApplication.class, args);
	}

}
